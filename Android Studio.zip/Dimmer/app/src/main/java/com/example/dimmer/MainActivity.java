package com.example.dimmer;

import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Set;

public class MainActivity extends AppCompatActivity {
    BluetoothAdapter bluetoothAdapter;  // Kendi bluetoothun
    Button button,devicebutton;
    TextView text;
    ListView devicelist;
    public static String EXTRA_ADRESS ="device_adress";
    private Set<BluetoothDevice> pairedDevices; // Etraftaki bluetooth verileri
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bluetoothAdapter=BluetoothAdapter.getDefaultAdapter(); //Cihazın bluetooth özelliği var mı ?


        text = findViewById(R.id.blue);
        button = findViewById(R.id.buton);
        devicebutton = findViewById(R.id.buttondevice);
        devicelist =findViewById(R.id.devicelist);

//g


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleBluetooth();
            }


        });

        devicebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listdevice();
            }


        });



    } private void listdevice() {

        pairedDevices =bluetoothAdapter.getBondedDevices();
        ArrayList list = new ArrayList();

        if(pairedDevices.size()>0){
            text.setText("");
            for(BluetoothDevice bt :pairedDevices){

                list.add(bt.getName()+"\n"+bt.getAddress());

            }
        }
        else
        {
            text.setText("Eşleşen cihaz yok");
        }
        final ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,list);
        devicelist.setAdapter(adapter);
        devicelist.setOnItemClickListener(selectDevice);
    }

    public AdapterView.OnItemClickListener selectDevice = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            String info =((TextView) view).getText().toString();
            String address = info.substring((info.length()-17));

            Intent comintent = new Intent(MainActivity.this,Comminication.class);
            comintent.putExtra(EXTRA_ADRESS,address);
            startActivity(comintent);
        }
    };

    private void toggleBluetooth() {
        if(bluetoothAdapter==null){



            Toast.makeText(getApplicationContext(),"Eşleşen Bluetooth cihazı yok",Toast.LENGTH_SHORT).show();

        }
        if (!bluetoothAdapter.isEnabled()){

            button.setText(R.string.bton);
            Intent enableBTIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);

            startActivity(enableBTIntent);
        }
        if (bluetoothAdapter.isEnabled()){

           button.setText(R.string.btof);
            bluetoothAdapter.disable();
        }
    }


}
