package com.example.dimmer;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.Toast;

import java.io.IOException;
import java.util.UUID;

public class Comminication extends AppCompatActivity {

    String address = null;
    private ProgressDialog progress;
    BluetoothAdapter bluetoothAdapter;

    BluetoothSocket btSocket = null;

SeekBar brightness,red,green,blue,red2,green2,blue2;

    Switch aSwitch ,bSwitch;
    int[] intArray,intArray2,intArray3,intArray4;
    ImageButton slot1,slot2,slot3,slot4;

    Button select;



private boolean isBtConnected =false;
static final UUID myUUID=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comminication);
        Intent newint = getIntent();
        brightness = findViewById(R.id.kaydirgac);
        red=findViewById(R.id.kaydirgacRed);
        green=findViewById(R.id.kaydirgacGreen);
        blue =findViewById(R.id.kaydirgacBlue);
        address=newint.getStringExtra(MainActivity.EXTRA_ADRESS);

        new BTbaglan().execute();







        //------------------------------***************************------------------------MAİN2-----------------------*************************************-------------------------
        slot1 =findViewById(R.id.imageButton1);
        slot2 =findViewById(R.id.imageButton2);
        slot3 =findViewById(R.id.imageButton3);
        slot4 =findViewById(R.id.imageButton4);

        red2=findViewById(R.id.seekBarRED);
        green2=findViewById(R.id.seekBarGREEN);
        blue2=findViewById(R.id.seekBarBLUE);







//------------------------------***************************------------------------EFFECTS-----------------------*************************************-------------------------


        bSwitch=findViewById(R.id.switch2);
        aSwitch=findViewById(R.id.switch1);
        final Switch fade =findViewById(R.id.fade);

        final Switch disco =findViewById(R.id.disco);

        aSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if(isChecked){

                    slot1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            red2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                                @Override
                                public void onProgressChanged(SeekBar seekBar, int progress1, boolean fromUser) {

                                    SetTheColor(slot1);
                                }

                                @Override
                                public void onStartTrackingTouch(SeekBar seekBar) {

                                }

                                @Override
                                public void onStopTrackingTouch(SeekBar seekBar) {
                                    GetTheColorSlot1(red2.getProgress(),green2.getProgress(),blue2.getProgress());
                                }
                            });
                            green2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                                @Override
                                public void onProgressChanged(SeekBar seekBar, int progress2, boolean fromUser) {
                                    SetTheColor(slot1);
                                }

                                @Override
                                public void onStartTrackingTouch(SeekBar seekBar) {

                                }

                                @Override
                                public void onStopTrackingTouch(SeekBar seekBar) {
                                    GetTheColorSlot1(red2.getProgress(),green2.getProgress(),blue2.getProgress());
                                }
                            });
                            blue2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                                @Override
                                public void onProgressChanged(SeekBar seekBar, int progress3, boolean fromUser) {
                                    SetTheColor(slot1);
                                }

                                @Override
                                public void onStartTrackingTouch(SeekBar seekBar) {

                                }

                                @Override
                                public void onStopTrackingTouch(SeekBar seekBar) {
                                    GetTheColorSlot1(red2.getProgress(),green2.getProgress(),blue2.getProgress());
                                }
                            });
                        }
                    });

                    slot2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            red2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                                @Override
                                public void onProgressChanged(SeekBar seekBar, int progress1, boolean fromUser) {

                                    SetTheColor(slot2);
                                }

                                @Override
                                public void onStartTrackingTouch(SeekBar seekBar) {

                                }

                                @Override
                                public void onStopTrackingTouch(SeekBar seekBar) {
                                    GetTheColorSlot2(red2.getProgress(),green2.getProgress(),blue2.getProgress());
                                }
                            });
                            green2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                                @Override
                                public void onProgressChanged(SeekBar seekBar, int progress2, boolean fromUser) {
                                    SetTheColor(slot2);
                                }

                                @Override
                                public void onStartTrackingTouch(SeekBar seekBar) {

                                }

                                @Override
                                public void onStopTrackingTouch(SeekBar seekBar) {
                                    GetTheColorSlot2(red2.getProgress(),green2.getProgress(),blue2.getProgress());
                                }
                            });
                            blue2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                                @Override
                                public void onProgressChanged(SeekBar seekBar, int progress3, boolean fromUser) {
                                    SetTheColor(slot2);
                                }

                                @Override
                                public void onStartTrackingTouch(SeekBar seekBar) {

                                }

                                @Override
                                public void onStopTrackingTouch(SeekBar seekBar) {
                                    GetTheColorSlot2(red2.getProgress(),green2.getProgress(),blue2.getProgress());
                                }
                            });
                        }
                    });

                    slot3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            red2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                                @Override
                                public void onProgressChanged(SeekBar seekBar, int progress1, boolean fromUser) {

                                    SetTheColor(slot3);
                                }

                                @Override
                                public void onStartTrackingTouch(SeekBar seekBar) {

                                }

                                @Override
                                public void onStopTrackingTouch(SeekBar seekBar) {
                                    GetTheColorSlot3(red2.getProgress(),green2.getProgress(),blue2.getProgress());
                                }
                            });
                            green2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                                @Override
                                public void onProgressChanged(SeekBar seekBar, int progress2, boolean fromUser) {
                                    SetTheColor(slot3);
                                }

                                @Override
                                public void onStartTrackingTouch(SeekBar seekBar) {

                                }

                                @Override
                                public void onStopTrackingTouch(SeekBar seekBar) {
                                    GetTheColorSlot3(red2.getProgress(),green2.getProgress(),blue2.getProgress());
                                }
                            });
                            blue2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                                @Override
                                public void onProgressChanged(SeekBar seekBar, int progress3, boolean fromUser) {
                                    SetTheColor(slot3);
                                }

                                @Override
                                public void onStartTrackingTouch(SeekBar seekBar) {

                                }

                                @Override
                                public void onStopTrackingTouch(SeekBar seekBar) {
                                    GetTheColorSlot3(red2.getProgress(),green2.getProgress(),blue2.getProgress());
                                }
                            });
                        }
                    });
                    slot4.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            red2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                                @Override
                                public void onProgressChanged(SeekBar seekBar, int progress1, boolean fromUser) {


                                    SetTheColor(slot4);
                                }

                                @Override
                                public void onStartTrackingTouch(SeekBar seekBar) {

                                }

                                @Override
                                public void onStopTrackingTouch(SeekBar seekBar) {
                                    GetTheColorSlot4(red2.getProgress(),green2.getProgress(),blue2.getProgress());
                                }
                            });
                            green2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                                @Override
                                public void onProgressChanged(SeekBar seekBar, int progress2, boolean fromUser) {

                                    SetTheColor(slot4);
                                }

                                @Override
                                public void onStartTrackingTouch(SeekBar seekBar) {

                                }

                                @Override
                                public void onStopTrackingTouch(SeekBar seekBar) {
                                    GetTheColorSlot4(red2.getProgress(),green2.getProgress(),blue2.getProgress());
                                }
                            });
                            blue2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                                @Override
                                public void onProgressChanged(SeekBar seekBar, int progress3, boolean fromUser) {

                                    SetTheColor(slot4);

                                }

                                @Override
                                public void onStartTrackingTouch(SeekBar seekBar) {

                                }

                                @Override
                                public void onStopTrackingTouch(SeekBar seekBar) {
                                    GetTheColorSlot4(red2.getProgress(),green2.getProgress(),blue2.getProgress());
                                }
                            });
                        }
                    });


                    fade.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                        @Override
                        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                            if(isChecked){

                                try {

                                    btSocket.getOutputStream().write(0x4e);      //N fade effect


                                } catch (IOException e) {
                                    e.printStackTrace();
                                }


                            }
                            else
                            {
                                try {


                                    btSocket.getOutputStream().write(0x6a);   // sign P fade off


                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }}
                    });


                    blue.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                        @Override
                        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {


                            Toast.makeText(getApplicationContext(), "progress level\n" + progress, Toast.LENGTH_SHORT).show();
                            if(btSocket!=null) {
                                try {
                                    btSocket.getOutputStream().write(0x3C);
                                    btSocket.getOutputStream().write(0x3a);   // sign : ilk blue
                                    btSocket.getOutputStream().write(progress);


                                    btSocket.getOutputStream().write(0x3E);
                                    Toast.makeText(getApplicationContext(), "progress level\n" + progress, Toast.LENGTH_SHORT).show();



                                } catch (IOException  e) {
                                    e.printStackTrace();
                                }
                            }
                        }


                        @Override
                        public void onStartTrackingTouch(SeekBar seekBar) {

                        }

                        @Override
                        public void onStopTrackingTouch(SeekBar seekBar) {

                        }
                    });

                    green.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                        @Override
                        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {



                            if(btSocket!=null) {
                                try {
                                    btSocket.getOutputStream().write(0x3C);
                                    btSocket.getOutputStream().write(0x3b);   // sign ; ilk green
                                    btSocket.getOutputStream().write(progress);

                                    btSocket.getOutputStream().write(0x3E);
                                    Toast.makeText(getApplicationContext(), "progress level\n" + progress, Toast.LENGTH_SHORT).show();

                                } catch (IOException  e) {
                                    e.printStackTrace();
                                }
                            }
                        }


                        @Override
                        public void onStartTrackingTouch(SeekBar seekBar) {

                        }

                        @Override
                        public void onStopTrackingTouch(SeekBar seekBar) {

                        }
                    });
                    red.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                        @Override
                        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                            Toast.makeText(getApplicationContext(), "progress level\n" + progress, Toast.LENGTH_SHORT).show();


                            if(btSocket!=null) {
                                try {
                                    btSocket.getOutputStream().write(0x3C);
                                    btSocket.getOutputStream().write(0x3d);   // sign = ilk red
                                    btSocket.getOutputStream().write(progress);

                                    btSocket.getOutputStream().write(0x3E);
                                    Toast.makeText(getApplicationContext(), "progress level\n" + progress, Toast.LENGTH_SHORT).show();


                                } catch (IOException  e) {
                                    e.printStackTrace();
                                }
                            }
                        }

                        @Override
                        public void onStartTrackingTouch(SeekBar seekBar) {

                        }

                        @Override
                        public void onStopTrackingTouch(SeekBar seekBar) {

                        }
                    });

                    brightness.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                        @Override
                        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {



                            if(btSocket!=null) {
                                try {

                                    btSocket.getOutputStream().write(0x3C);
                                    btSocket.getOutputStream().write(0x3f);   // sign ? ilk parlaklık
                                    btSocket.getOutputStream().write(progress);
                                    btSocket.getOutputStream().write(0x3E);
                                    Toast.makeText(getApplicationContext(), "progress level\n" + progress, Toast.LENGTH_SHORT).show();

                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                        }


                        @Override
                        public void onStartTrackingTouch(SeekBar seekBar) {


                        }

                        @Override
                        public void onStopTrackingTouch(SeekBar seekBar) {

                        }
                    });


                    bSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                        @Override
                        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                            if(isChecked){
                                try {
                                    btSocket.getOutputStream().write(0x7a);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                                int data1= intArray[0];
                                int data2= intArray[1];
                                int data3= intArray[2];
                                // -------------------------------------------------------------------
                                try {
                                    btSocket.getOutputStream().write(0x3C);
                                    btSocket.getOutputStream().write(0x40);   // sign @ slot1 red
                                    btSocket.getOutputStream().write(data1);
                                    btSocket.getOutputStream().write(0x3E);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                                try {
                                    btSocket.getOutputStream().write(0x3C);
                                    btSocket.getOutputStream().write(0x41);   // sign A slot1 green
                                    btSocket.getOutputStream().write(data2);
                                    btSocket.getOutputStream().write(0x3E);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                                try {
                                    btSocket.getOutputStream().write(0x3C);
                                    btSocket.getOutputStream().write(0x42);   // sign B slot1 blue
                                    btSocket.getOutputStream().write(data3);
                                    btSocket.getOutputStream().write(0x3E);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }



                                // -------------------------------------------------------------------
                                // -------------------------------------------------------------------
                                // -------------------------------------------------------------------


                                int data4= intArray2[0];
                                int data5= intArray2[1];
                                int data6= intArray2[2];
                                // -------------------------------------------------------------------
                                try {
                                    btSocket.getOutputStream().write(0x3C);
                                    btSocket.getOutputStream().write(0x43);   // sign C slot1 red
                                    btSocket.getOutputStream().write(data4);
                                    btSocket.getOutputStream().write(0x3E);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                                // -------------------------------------------------------------------
                                try {
                                    btSocket.getOutputStream().write(0x3C);
                                    btSocket.getOutputStream().write(0x44);   // sign D slot1 green
                                    btSocket.getOutputStream().write(data5);
                                    btSocket.getOutputStream().write(0x3E);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                                // -------------------------------------------------------------------
                                try {
                                    btSocket.getOutputStream().write(0x3C);
                                    btSocket.getOutputStream().write(0x45);   // sign E slot1 blue
                                    btSocket.getOutputStream().write(data6);
                                    btSocket.getOutputStream().write(0x3E);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }


                                // -------------------------------------------------------------------
                                // -------------------------------------------------------------------
                                // -------------------------------------------------------------------

                                int data7= intArray3[0];
                                int data8= intArray3[1];
                                int data9= intArray3[2];
                                // -------------------------------------------------------------------
                                try {
                                    btSocket.getOutputStream().write(0x3C);
                                    btSocket.getOutputStream().write(0x46);   // sign F slot1 red
                                    btSocket.getOutputStream().write(data7);
                                    btSocket.getOutputStream().write(0x3E);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                                // -------------------------------------------------------------------
                                try {
                                    btSocket.getOutputStream().write(0x3C);
                                    btSocket.getOutputStream().write(0x47);   // sign G slot1 green
                                    btSocket.getOutputStream().write(data8);
                                    btSocket.getOutputStream().write(0x3E);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                                // -------------------------------------------------------------------
                                try {
                                    btSocket.getOutputStream().write(0x3C);
                                    btSocket.getOutputStream().write(0x48);   // sign H slot1 blue
                                    btSocket.getOutputStream().write(data9);
                                    btSocket.getOutputStream().write(0x3E);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                                int data10= intArray4[0];
                                int data11= intArray4[1];
                                int data12= intArray4[2];
                                // -------------------------------------------------------------------
                                try {
                                    btSocket.getOutputStream().write(0x3C);
                                    btSocket.getOutputStream().write(0x49);   // sign I slot1 red
                                    btSocket.getOutputStream().write(data10);
                                    btSocket.getOutputStream().write(0x3E);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                                // -------------------------------------------------------------------
                                try {
                                    btSocket.getOutputStream().write(0x3C);
                                    btSocket.getOutputStream().write(0x4a);   // sign J slot1 green
                                    btSocket.getOutputStream().write(data11);
                                    btSocket.getOutputStream().write(0x3E);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                                // -------------------------------------------------------------------
                                try {
                                    btSocket.getOutputStream().write(0x3C);
                                    btSocket.getOutputStream().write(0x4b);   // sign K slot1 blue
                                    btSocket.getOutputStream().write(data12);
                                    btSocket.getOutputStream().write(0x3E);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }



                            }
                            else
                            {
                                try {
                                    btSocket.getOutputStream().write(0x7b);



                                } catch (IOException e) {
                                    e.printStackTrace();
                                }


                            }


                        }
                    });












                    disco.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                        @Override
                        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                            if(isChecked){


                                try {


                                    btSocket.getOutputStream().write(0x6d);   // sign Q disco on


                                } catch (IOException e) {
                                    e.printStackTrace();
                                }



                            }
                            else {

                                try {


                                    btSocket.getOutputStream().write(0x6f);   // sign R disco off



                                } catch (IOException e) {
                                    e.printStackTrace();
                                }

                            }

                        }
                    });










                    //    byte startMarker = 0x3C;
                    //    byte endMarker = 0x3E;
                }
                else
                {
                    try {
                       btSocket.getOutputStream().write(0x3C);
                       btSocket
                               .getOutputStream().write(0x3f);
                        btSocket.getOutputStream().write(0);   // sign M off efekti
                        btSocket.getOutputStream().write(0x3E);

                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                }

            }
        });







    }

    public void SetTheColor(ImageView slots){


        slots.setBackgroundColor(Color.rgb(red2.getProgress(),green2.getProgress(),blue2.getProgress()));
    }



    public void GetTheColorSlot1(int red,int green,int blue )  {

        intArray = new int[]{ red,green,blue};

    }
    public void GetTheColorSlot2(int red,int green,int blue )  {

        intArray2 = new int[]{ red,green,blue};

    }public void GetTheColorSlot3(int red,int green,int blue )  {

        intArray3 = new int[]{ red,green,blue};


    }public void GetTheColorSlot4(int red,int green,int blue )  {

        intArray4 = new int[]{ red,green,blue};




    }



    private void Disconnect(){
        if(btSocket!=null){
            try {
                btSocket.close();
            } catch (IOException e){
                // msg("Error");
            }
        }
        finish();
    }



    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Disconnect();
    }

    private class BTbaglan extends AsyncTask<Void, Void, Void> {
        private boolean ConnectSuccess = true;

        @Override
        protected void onPreExecute() {
            progress = ProgressDialog.show(Comminication.this, "Baglanıyor...", "Lütfen Bekleyin");
        }



        @Override
        protected Void doInBackground(Void... devices) {
            try {
                if (btSocket == null || !isBtConnected) {
                    bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
                    BluetoothDevice cihaz = bluetoothAdapter.getRemoteDevice(address);
                    btSocket = cihaz.createInsecureRfcommSocketToServiceRecord(myUUID);
                    BluetoothAdapter.getDefaultAdapter().cancelDiscovery();
                    btSocket.connect();
                }
            } catch (IOException e) {
                ConnectSuccess = false;
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            if (!ConnectSuccess) {
                // msg("Baglantı Hatası, Lütfen Tekrar Deneyin");
                Toast.makeText(getApplicationContext(),"Bağlantı Hatası Tekrar Deneyin",Toast.LENGTH_SHORT).show();
                finish();
            } else {
                //   msg("Baglantı Basarılı");
                Toast.makeText(getApplicationContext(),"Bağlantı Başarılı",Toast.LENGTH_SHORT).show();

                isBtConnected = true;
            }
            progress.dismiss();
        }

    }
}
